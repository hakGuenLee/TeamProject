package ezen.team.mapper;

import org.apache.ibatis.annotations.Mapper;

//BoardServiceImple과 연결

@Mapper
public interface BoardMapper {

}
