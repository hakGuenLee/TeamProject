package ezen.team.mapper;

import org.apache.ibatis.annotations.Mapper;

//OrderServiceImpl과 연결

@Mapper
public interface OrderMapper {

}
