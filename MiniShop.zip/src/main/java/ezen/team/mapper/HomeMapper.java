package ezen.team.mapper;

import org.apache.ibatis.annotations.Mapper;

//HomeServiceImpl과 연결

@Mapper
public interface HomeMapper {

}
