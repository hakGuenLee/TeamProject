package ezen.team.mapper.admin;



import org.apache.ibatis.annotations.Mapper;

import ezen.team.domain.AdminDTO;
import ezen.team.domain.EmpDTO;

//AdminServiceImpl과 연결

@Mapper
public interface AdminMapper {

	//관리자 등록
	void adminRegister(AdminDTO aDto);

	//사번 검색
	EmpDTO getEmp(String name);

}
