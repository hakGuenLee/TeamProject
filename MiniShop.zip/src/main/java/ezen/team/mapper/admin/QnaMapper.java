package ezen.team.mapper.admin;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface QnaMapper {

}
