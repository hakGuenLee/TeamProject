//package ezen.team.mapper.admin;
//
//import org.apache.ibatis.annotations.Mapper;
//import org.springframework.security.core.userdetails.UserDetails;
//
//@Mapper
//public interface LoginMapper {
//
//	//관리자 로그인 정보 가져오기
//	UserDetails getUserDetails(String username);
//
//}
