package ezen.team.mapper.admin;

import org.apache.ibatis.annotations.Mapper;

//CategoryServiceImpl과 연결

@Mapper
public interface CategoryMapper {

}
