package ezen.team.mapper;

import org.apache.ibatis.annotations.Mapper;

//UserServiceImpl과 연결

@Mapper
public interface UserMapper {

}
