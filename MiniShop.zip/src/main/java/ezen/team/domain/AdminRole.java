package ezen.team.domain;


//관리자 권한 설정 
public class AdminRole {

}
