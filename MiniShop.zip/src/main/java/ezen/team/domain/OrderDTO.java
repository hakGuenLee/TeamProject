package ezen.team.domain;

import lombok.Getter;
import lombok.Setter;

//주문/배송목록

@Getter
@Setter
public class OrderDTO {

}
