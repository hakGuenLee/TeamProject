package ezen.team.controller.shop;

import org.springframework.stereotype.Controller;

/* 
아이디 찾기
비밀번호 찾기
회원가입 처리
찜리스트 저장
상품별 페이지 이동
상품 상세 페이지 처리
상품 리뷰 등록처리
상품 문의하기
상품 검색
 */

@Controller
public class ShopController {

}
