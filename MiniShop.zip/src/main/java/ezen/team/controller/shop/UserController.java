package ezen.team.controller.shop;

import org.springframework.stereotype.Controller;

/*
로그인
로그아웃
마이페이지 이동
마이페이지_찜리스트
마이페이지_적립금
마이페이지_1:!문의내역
마이페이지_주문/배송조회
마이페이지_제품문의내역
마이페이지_회원탈퇴
마이페이지_회원정보 수정
 */


@Controller
public class UserController {

}
