package ezen.team.controller.shop;

import org.springframework.stereotype.Controller;

/*
주문 페이지 이동(주문정보, 회원정보 같이 출력)
결제수단 선택
주문 완료처리(정보제공 동의박스 유효성 검사, 이상 없을 시 주문 완료처리)
 */


@Controller
public class OrderController {

}
