package ezen.team.controller.shop;

import org.springframework.stereotype.Controller;

/*
공지사항
FAQ
1:1문의하기
 */



@Controller
public class BoardController {

}
