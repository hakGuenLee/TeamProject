package ezen.team.controller.shop;

import org.springframework.stereotype.Controller;

/*
장바구니 페이지 이동 및 리스트 출력
선택상품 삭제
 */

@Controller
public class CartController {

}
