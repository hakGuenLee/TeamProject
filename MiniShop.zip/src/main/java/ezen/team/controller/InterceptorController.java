package ezen.team.controller;

import org.springframework.stereotype.Controller;

//인터셉터 

@Controller
public class InterceptorController {

}
