package ezen.team.controller.admin;

import org.springframework.stereotype.Controller;

//공통코드 호출 처리 컨트롤러

@Controller
public class CommonCodeController {

}
