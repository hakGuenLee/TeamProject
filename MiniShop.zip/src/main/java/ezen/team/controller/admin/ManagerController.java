package ezen.team.controller.admin;

import org.springframework.stereotype.Controller;

/* 
공지사항 등록
팝업 등록
승인 요청하기 
 */


@Controller
public class ManagerController {

}
