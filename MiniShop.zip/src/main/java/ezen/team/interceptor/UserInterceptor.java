package ezen.team.interceptor;

import org.springframework.web.servlet.HandlerInterceptor;


//사용자 로그인 인터셉터(임시로 만들어두었습니다)

public class UserInterceptor implements HandlerInterceptor {

}
