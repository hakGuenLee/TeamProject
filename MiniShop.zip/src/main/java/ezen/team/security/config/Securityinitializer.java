
package ezen.team.security.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;
 

//Delegating FilterProxy 등록 클래스

public class Securityinitializer extends
 AbstractSecurityWebApplicationInitializer {
 
 }
