package ezen.team.security.common;


import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import ezen.team.domain.AdminDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
public class AdminContext extends User {


	

	private String username;
	private String password;
	/* private Collection<? extends GrantedAuthority> authorities; */
	
	
	public AdminContext(String username, String password, Collection<? extends GrantedAuthority> authorities) {
		super(username, password, authorities);
		
		this.username = username;
		this.password = password;
		/* this.authorities = authorities; */
	
	}
	








	

	
	

}
