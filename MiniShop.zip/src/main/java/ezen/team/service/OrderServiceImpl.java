package ezen.team.service;

import org.springframework.stereotype.Service;

//OrderController와 연결

@Service
public class OrderServiceImpl {

}
