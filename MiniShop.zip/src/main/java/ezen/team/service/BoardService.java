package ezen.team.service;

public interface BoardService {

}
