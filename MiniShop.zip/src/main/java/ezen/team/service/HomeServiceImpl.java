package ezen.team.service;

import org.springframework.stereotype.Service;

@Service
public class HomeServiceImpl implements HomeService {

}
