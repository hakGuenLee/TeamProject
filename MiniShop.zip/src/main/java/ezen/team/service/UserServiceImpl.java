package ezen.team.service;

import org.springframework.stereotype.Service;

//UserController와 연결

@Service
public class UserServiceImpl {

}
