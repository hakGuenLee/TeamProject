package ezen.team.service.admin;

import org.springframework.stereotype.Service;

//QnaController와 연결

@Service
public class QnaServiceImpl implements QnaService {

}
