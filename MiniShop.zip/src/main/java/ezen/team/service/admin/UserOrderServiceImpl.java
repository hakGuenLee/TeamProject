package ezen.team.service.admin;

import org.springframework.stereotype.Service;

//UserOrderController

@Service
public class UserOrderServiceImpl {

}
