package ezen.team.service.admin;


//NoticeController와 연결
public interface NoticeService {

}
