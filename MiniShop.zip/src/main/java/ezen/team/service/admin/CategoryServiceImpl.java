package ezen.team.service.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ezen.team.domain.CategoryDTO;
import ezen.team.mapper.admin.CategoryMapper;

@Service
public class CategoryServiceImpl implements CategoryService {
	
	@Autowired
	CategoryMapper mapper;
	
	   @Override
	   public List<CategoryDTO> catList() {
	      
	      List<CategoryDTO> cList = mapper.catList();
	      
	      System.out.println(cList);
	      
	      return cList;
	   }

	@Override
	public void catRegister(CategoryDTO cdto) {
		
		 mapper.catRegister(cdto);
		
	}

	@Override
	public CategoryDTO catListByNo(String no) {
		
		CategoryDTO cdto = mapper.catListByNo(no);
		
		return cdto;
	}

	@Override
	public void catUpdate(CategoryDTO cdto) {
		
		mapper.catUpdate(cdto);
		
	}

}
