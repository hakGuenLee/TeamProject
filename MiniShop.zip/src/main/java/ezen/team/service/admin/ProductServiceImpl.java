package ezen.team.service.admin;

import org.springframework.stereotype.Service;

//ProductController와 연결


@Service
public class ProductServiceImpl implements ProductService {

}
