package ezen.team.service.admin;

public interface QnaService {

}
