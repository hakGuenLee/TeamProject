package ezen.team.service.admin;


import ezen.team.domain.AdminDTO;
import ezen.team.domain.EmpDTO;

public interface AdminService {
	
	
	void adminRegister(AdminDTO aDto);
	
	EmpDTO getEmpList(String name);

}
