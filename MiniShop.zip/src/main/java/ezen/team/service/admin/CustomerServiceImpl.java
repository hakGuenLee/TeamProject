package ezen.team.service.admin;

import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService {

}
