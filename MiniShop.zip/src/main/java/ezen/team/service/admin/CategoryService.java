package ezen.team.service.admin;

import java.util.List;

import ezen.team.domain.CategoryDTO;



public interface CategoryService {

	List<CategoryDTO> catList();
	
}
