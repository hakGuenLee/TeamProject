package ezen.team.service.admin;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ezen.team.domain.AdminDTO;
import ezen.team.domain.EmpDTO;
import ezen.team.mapper.admin.AdminMapper;

//AdminController와 연결

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	AdminMapper mapper;
	
	
	//관리자 등록
	public void adminRegister(AdminDTO aDto) {

		mapper.adminRegister(aDto);		
		
	}

	//관리자 등록 페이지 사번 검색하기
	public EmpDTO getEmpList(String name) {
		
		EmpDTO eDto = mapper.getEmp(name);
		
		System.out.println("서비스단 eDto : " + eDto);
		
		return eDto;
	}

}
