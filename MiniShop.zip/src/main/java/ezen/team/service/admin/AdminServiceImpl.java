package ezen.team.service.admin;

import org.springframework.stereotype.Service;

//AdminController와 연결

@Service
public class AdminServiceImpl implements AdminService {

}
