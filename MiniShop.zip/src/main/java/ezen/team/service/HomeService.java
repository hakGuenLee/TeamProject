package ezen.team.service;

public interface HomeService {

}
